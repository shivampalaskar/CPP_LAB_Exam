#include <iostream>
#include <iomanip>
#include "Deposit.h"
#include "RecurringDeposit.h"
#include "FixedDeposit.h"
#include "ShareMarket.h"
#include "MinimumAmountException.h"
using namespace std;

int menuList() {
	int choice;
	cout << "0. Exit" << endl;
	cout << "1. Open Recurring Deposit Account" << endl;
	cout << "2. Open Fixed Deposit Account" << endl;
	cout << "3. Share Market Investment" << endl;
	cout << "Enter Choice: ";
	cin >> choice;
	return choice;
}

int main(void) {
	Deposit *dptr[3];
	int choice, count = 0;
	while (count < 3) {
		choice = menuList();
		switch (choice) {
		case 0:
			return 0;
		case 1: {
			dptr[count] = new RecurringDeposit;
			try {
				dptr[count]->accept();
				count++;
			} catch (MinimumAmountException &obj) {
				obj.printMsg();
				delete dptr[count];
			}
			break;
		}
		case 2: {
			dptr[count] = new FixedDeposit;
			try {
				dptr[count]->accept();
				count++;
			} catch (MinimumAmountException &obj) {
				obj.printMsg();
				delete dptr[count];
			}
			break;
		}
		case 3: {
			dptr[count] = new ShareMarket;
			try {
				dptr[count]->accept();
				count++;
			} catch (MinimumAmountException &obj) {
				obj.printMsg();
				delete dptr[count];
			}
			break;
		}
		}
	}
	for (int i = 0; i < count; i++) {
		cout<<"=============================================="<<endl;
		dptr[i]->display();
		cout << "Maturity Amount After 5 Years : "
				<< dptr[i]->calc_maturity_amt() << endl;
	}

	for (int i = 0; i < count; i++) {
		delete dptr[i];
	}

	return 0;
}

