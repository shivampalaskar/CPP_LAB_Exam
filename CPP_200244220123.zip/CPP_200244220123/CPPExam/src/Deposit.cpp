/*
 * Deposit.cpp
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#include <iostream>
#include <cstring>
#include "Deposit.h"
#include "MinimumAmountException.h"
using namespace std;

Deposit::Deposit() {
	this->customer_id=0;
	strcpy(this->name,"");
	this->amt=0.0f;
	this->interest=0.0f;
}

Deposit::Deposit(const char* name,int id,float amt,float interest){
	strcpy(this->name,name);
	this->customer_id=id;
	this->amt=amt;
	this->interest=interest;
}

float Deposit::getAmt() {
	return this->amt;
}

void Deposit::setAmt(float amt) {
	this->amt = amt;
}

int Deposit::getCustomerId() {
	return this->customer_id;
}

void Deposit::setCustomerId(int customerId) {
	this->customer_id = customerId;
}

float Deposit::getInterest() {
	return this->interest;
}

void Deposit::setInterest(float interest) {
	this->interest = interest;
}

const char* Deposit::getName() {
	return name;
}

void Deposit::setName(const char* name){
	strcpy(this->name,name);
}

/*void Deposit::display(){
	cout<<"Customer Name : "<<this->name<<endl;
	cout<<"Customer ID : "<<this->customer_id<<endl;
	cout<<"Amount : "<<this->amt<<endl;
	cout<<"Interest : "<<this->interest<<"% Per Month"<<endl;
}*/

/*void Deposit::accept() {
	cout << "Customer Name : ";
	cin>>this->name;
	cout << "Customer ID : ";
	cin>>this->customer_id;
	cout << "Amount : ";
	cin>>this->amt;
	//Need to set INTEREST as per account type
}*/
Deposit::~Deposit() {
	// TODO Auto-generated destructor stub
}

