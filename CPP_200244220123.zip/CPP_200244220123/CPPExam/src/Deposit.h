/*
 * Deposit.h
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#ifndef SRC_DEPOSIT_H_
#define SRC_DEPOSIT_H_

class Deposit {
	char name[20];
	int customer_id;
	float amt,interest;
public:
	Deposit();
	Deposit(const char*,int,float,float);
	float getAmt();
	void setAmt(float amt);
	int getCustomerId();
	void setCustomerId(int customerId);
	float getInterest();
	void setInterest(float interest);
	const char* getName();
	void setName(const char*);
	virtual void display()=0;
	virtual void accept()=0;
	virtual float calc_maturity_amt()=0;
	virtual ~Deposit();
};

#endif /* SRC_DEPOSIT_H_ */
