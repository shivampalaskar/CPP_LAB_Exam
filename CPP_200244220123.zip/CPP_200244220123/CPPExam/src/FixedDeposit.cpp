/*
 * FixedDeposit.cpp
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */
#include <iostream>
#include "FixedDeposit.h"
#include "MinimumAmountException.h"
using namespace std;

FixedDeposit::FixedDeposit() {
	this->setInterest(1);
}

FixedDeposit::FixedDeposit(const char* name, int id, float amt) :
		Deposit(name, id, amt, 1) {
}

float FixedDeposit::calc_maturity_amt() {
	float maturity_amt = this->getAmt();
	int total_month = 60;  //5 Years
	float interest=0;
	for(int i=0;i<total_month;i++){
		interest = maturity_amt * 0.01f;
		maturity_amt = maturity_amt + interest;
	}
	return maturity_amt;
}

void FixedDeposit::accept(){
	char name[20];
	int id;
	float amt;
	cout << "Customer Name : ";
	cin >> name;
	this->setName(name);
	cout << "Customer ID : ";
	cin >> id;
	this->setCustomerId(id);
	cout << "Amount : ";
	cin >> amt;
	if(amt<=40000)
		throw MinimumAmountException(40000,amt);
	this->setAmt(amt);
}

void FixedDeposit::display(){
	cout<<"Fixed Deposit Account"<<endl;
	cout<<"Customer Name : "<<this->getName()<<endl;
	cout<<"Customer ID : "<<this->getCustomerId()<<endl;
	cout<<"Amount : "<<this->getAmt()<<endl;
	cout<<"Interest : "<<this->getInterest()<<"% Per Month"<<endl;
}

FixedDeposit::~FixedDeposit() {
}

