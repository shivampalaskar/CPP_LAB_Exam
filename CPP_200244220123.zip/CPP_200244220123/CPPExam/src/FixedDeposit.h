/*
 * FixedDeposit.h
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */
#include "Deposit.h"
#ifndef SRC_FIXEDDEPOSIT_H_
#define SRC_FIXEDDEPOSIT_H_

class FixedDeposit : public Deposit{
public:
	FixedDeposit();
	FixedDeposit(const char*,int,float);
	void accept();
	void display();
	float calc_maturity_amt();
	~FixedDeposit();
};

#endif /* SRC_FIXEDDEPOSIT_H_ */
