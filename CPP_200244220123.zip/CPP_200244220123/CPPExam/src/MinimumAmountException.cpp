/*
 * MinimumAmountException.cpp
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#include <iostream>
#include "MinimumAmountException.h"
using namespace std;

MinimumAmountException::MinimumAmountException() {
}

MinimumAmountException::MinimumAmountException(float min_bal,float entered_amt) {
	this->min_bal=min_bal;
	this->entered_amt = entered_amt;
}

void MinimumAmountException::printMsg(){
	cout<<"Minimum Amount Should Be : "<<this->min_bal<<endl;
	cout<<"Your Entered Amount Is: "<<this->entered_amt<<endl;
}
MinimumAmountException::~MinimumAmountException() {
	// TODO Auto-generated destructor stub
}

