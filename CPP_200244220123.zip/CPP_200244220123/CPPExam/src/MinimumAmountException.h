/*
 * MinimumAmountException.h
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#ifndef SRC_MINIMUMAMOUNTEXCEPTION_H_
#define SRC_MINIMUMAMOUNTEXCEPTION_H_

class MinimumAmountException {
	float min_bal,entered_amt;
public:
	MinimumAmountException();
	MinimumAmountException(float,float);
	void printMsg();
	~MinimumAmountException();
};

#endif /* SRC_MINIMUMAMOUNTEXCEPTION_H_ */
