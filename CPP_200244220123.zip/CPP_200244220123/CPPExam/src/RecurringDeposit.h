/*
 * RecurringDeposit.h
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#include "Deposit.h"
#ifndef SRC_RECURRINGDEPOSIT_H_
#define SRC_RECURRINGDEPOSIT_H_

class RecurringDeposit : public Deposit{
public:
	RecurringDeposit();
	RecurringDeposit(const char*,int,float);
	void accept();
	void display();
	float calc_maturity_amt();
	~RecurringDeposit();
};

#endif /* SRC_RECURRINGDEPOSIT_H_ */
