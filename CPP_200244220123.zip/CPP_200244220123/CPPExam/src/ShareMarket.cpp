/*
 * ShareMarket.cpp
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#include <iostream>
#include "MinimumAmountException.h"
#include "ShareMarket.h"
using namespace std;

ShareMarket::ShareMarket() {
	this->setInterest(1);
}

ShareMarket::ShareMarket(const char* name, int id, float amt) :
		Deposit(name, id, amt, 1) {
}

float ShareMarket::calc_maturity_amt() {
	float maturity_amt = this->getAmt();
	float interest=0,serivceCharge=0;
	for(int i=0;i<5;i++){
		for (int j = 0; j < 12; j++) {
			interest = maturity_amt * 0.016f;
			maturity_amt = maturity_amt + interest;
		}
		serivceCharge = maturity_amt*0.2;
		maturity_amt = maturity_amt - serivceCharge;
	}
	return maturity_amt;
}

void ShareMarket::accept(){
	char name[20];
	int id;
	float amt;
	cout << "Customer Name : ";
	cin >> name;
	this->setName(name);
	cout << "Customer ID : ";
	cin >> id;
	this->setCustomerId(id);
	cout << "Amount : ";
	cin >> amt;
	if(amt<=50000)
		throw MinimumAmountException(50000,amt);
	this->setAmt(amt);
}

void ShareMarket::display(){
	cout<<"Recurring Deposit Account"<<endl;
	cout<<"Customer Name : "<<this->getName()<<endl;
	cout<<"Customer ID : "<<this->getCustomerId()<<endl;
	cout<<"Amount : "<<this->getAmt()<<endl;
	cout<<"Interest : "<<this->getInterest()<<"% Per Month"<<endl;
}

ShareMarket::~ShareMarket() {
}

