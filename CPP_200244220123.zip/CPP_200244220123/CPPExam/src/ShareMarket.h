/*
 * ShareMarket.h
 *
 *  Created on: 11-Mar-2020
 *      Author: sunbeam
 */

#include "Deposit.h"
#ifndef SRC_SHAREMARKET_H_
#define SRC_SHAREMARKET_H_

class ShareMarket : public Deposit{
public:
	ShareMarket();
	ShareMarket(const char*,int,float);
	void accept();
	void display();
	float calc_maturity_amt();
	~ShareMarket();
};

#endif /* SRC_SHAREMARKET_H_ */
